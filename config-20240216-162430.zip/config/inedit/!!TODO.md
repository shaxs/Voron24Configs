

```
I think this will also work...You can use the \n to do a new line so that it is not one long string...
    {action_respond_info("Print_Start Macro Inputs:\n"
                         "BED = %d\n" 
                         "EXTRUDER = %d\n" 
                         "CHAMBER = %d\n"
                         "FL_SIZE == %s\n"
                         "material = %s\n"
                         "Z_Adjust = %.3f\n" 
                         "nozzle = %.2f"\n
                         "filament_name = %s\n" % 
                         (BED, EXTRUDER, CHAMBER, FL_SIZE, material, z_adjust, nozzle, filament_name))}
```


## General


- Macro ideas
    - https://github.com/zellneralex/klipper_config/tree/master
- Filament sensor
    - https://www.amazon.com/dp/B07Z97582P/?coliid=I278JGHS5OD8M7&colid=3T6GGJW7T3YSG&psc=1&ref_=lv_ov_lig_dp_it
    - https://www.printables.com/en/model/231626-bigtreetech-smart-filament-sensor-sfs-bracket-for-/files
    - https://www.teamfdm.com/files/file/417-exhaust-cover-sfs/



## TO PRINT
- back filler plate
    - https://github.com/VoronDesign/VoronUsers/tree/master/printer_mods/richardjm/back-plate
- clips?
    - https://github.com/v6cl/My-Voron2.4-Customs/blob/main/InteriorStuff/Panel_Locker/v2_Thin%20Locker/Thin_Locker_5.5mm.stl

## TO BUILD


