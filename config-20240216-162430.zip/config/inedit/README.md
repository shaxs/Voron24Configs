# VoronConfigs

adapted from the excellent work from https://github.com/Frix-x/klipper-voron-V2

some stuff changed to match LDO 2.4 350mm kit


https://paypal.me/ericrzimmerman
